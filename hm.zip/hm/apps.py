from django.apps import AppConfig


class HmConfig(AppConfig):
    name = 'hm'
